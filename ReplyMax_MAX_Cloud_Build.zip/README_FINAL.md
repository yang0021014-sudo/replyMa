# ReplyMax MAX 1.0

这是一个 Android AI 输入法完整工程。

## 技术基础
ReplyMax 使用 Android `InputMethodService`，系统安装后可以作为输入法使用，并通过 `InputConnection` 把候选回复直接提交到当前输入框。

## 构建
推荐 Android Studio Quail 4 / 2026.1.4。
项目使用 Android Gradle Plugin 9.2.0、Kotlin 2.2.10、compileSdk 36。

打开项目后：
1. Sync Project with Gradle Files
2. Build > Build APK(s)
3. 安装 APK
4. Android 设置 > 系统 > 键盘/输入法 > 启用 ReplyMax MAX
5. 在微信输入框切换到 ReplyMax MAX

## 当前功能
- AI 输入法服务
- 7 种回复风格
- 剪贴板读取
- 三候选回复
- 点击候选直接插入当前输入框
- 密码输入框自动隐藏
- 独立设置页
- 本地回复引擎

## AI 后端
工程没有偷偷绑定第三方 API。正式商业版建议增加：
POST /v1/chat
输入：对方消息、你的草稿、风格、亲密度、真人感
输出：3 条候选回复

这样可以接入你自己的模型/API，并把 API Key 放在服务端，而不是 APK 中。

## 重要
输入法具有处理用户输入文本的能力。发布前应完善隐私政策、数据最小化、加密传输、日志脱敏以及敏感字段保护。
