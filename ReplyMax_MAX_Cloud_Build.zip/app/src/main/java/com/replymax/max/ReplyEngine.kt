package com.replymax.max

data class ReplySettings(
    val mode: String = "高情商",
    val intimacy: Int = 3,
    val human: Int = 5,
    val emoji: Boolean = true
)

object ReplyEngine {
    fun generate(input: String, s: ReplySettings): List<String> {
        val clean = input.trim().ifEmpty { "刚刚那句话" }
        val e = if (s.emoji) listOf("🙂","哈哈","😌","✨").random() else ""
        return when (s.mode) {
            "温柔" -> listOf("我懂你的意思，慢慢来就好 $e", "听到了，也很在意你说的这些 $e", "别给自己太大压力，有我在。")
            "幽默" -> listOf("你这句话让我CPU都要转冒烟了 😂", "行，你成功把我整不会了哈哈 $e", "收到，今天的聊天难度突然上升了。")
            "暧昧" -> listOf("你这样说，我可要多想一点了 $e", "那你是在暗示我吗？", "如果是你，我好像愿意试试看。")
            "高冷" -> listOf("嗯，知道了。", "可以，继续说。", "我听着。")
            "安慰" -> listOf("别一个人扛着，想说就跟我说。", "我知道你现在可能不太好受，慢一点没关系。", "这件事不代表你不够好，真的。")
            "拒绝" -> listOf("谢谢你认真跟我说，不过这次我可能没办法答应。", "我理解你的想法，但我还是想委婉地说不。", "真的很感谢你，不过我更希望我们保持现在的关系。")
            else -> listOf("我懂你的意思，听起来你更在意的是这件事本身。", "收到，我认真看了。我们可以慢慢聊。", "嗯，我明白。你继续说，我在听。")
        }.map { if (s.human >= 4) it.replace("，", "，") else it }
    }
}
