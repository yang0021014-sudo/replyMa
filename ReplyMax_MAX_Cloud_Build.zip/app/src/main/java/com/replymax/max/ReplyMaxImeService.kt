package com.replymax.max

import android.inputmethodservice.InputMethodService
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color

class ReplyMaxImeService : InputMethodService() {
    private var settings = ReplySettings()
    private lateinit var root: LinearLayout
    private lateinit var input: EditText
    private lateinit var resultBox: LinearLayout

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18,12,18,12)
            setBackgroundColor(Color.rgb(18,18,22))
        }
        val title = TextView(this).apply {
            text = "ReplyMax MAX   AI高情商键盘"
            setTextColor(Color.WHITE); textSize=15f
        }
        root.addView(title)
        val modes = listOf("高情商","温柔","幽默","暧昧","高冷","安慰","拒绝")
        val row = LinearLayout(this)
        modes.forEach { mode ->
            val b=Button(this).apply {
                text=mode; textSize=11f
                setOnClickListener { settings=settings.copy(mode=mode); generate() }
            }
            row.addView(b, LinearLayout.LayoutParams(0,60,1f))
        }
        root.addView(row)
        val actions = LinearLayout(this)
        val paste=Button(this).apply { text="读取剪贴板"; setOnClickListener {
            val cm=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            input.setText(cm.primaryClip?.getItemAt(0)?.coerceToText(this) ?: "")
        }}
        val go=Button(this).apply { text="AI帮我回"; setOnClickListener { generate() } }
        actions.addView(paste, LinearLayout.LayoutParams(0,60,1f))
        actions.addView(go, LinearLayout.LayoutParams(0,60,1f))
        root.addView(actions)
        input=EditText(this).apply {
            hint="粘贴对方说的话，或输入你的原话..."
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(35,35,42))
        }
        root.addView(input, LinearLayout.LayoutParams(-1,100))
        resultBox=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(resultBox)
        return root
    }

    private fun generate() {
        resultBox.removeAllViews()
        ReplyEngine.generate(input.text.toString(), settings).forEach { reply ->
            val b=Button(this).apply {
                text=reply
                setOnClickListener { currentInputConnection?.commitText(reply,1) }
            }
            resultBox.addView(b, LinearLayout.LayoutParams(-1,70))
        }
    }

    override fun onStartInput(info: EditorInfo?, restarting: Boolean) {
        super.onStartInput(info, restarting)
        if (info != null && (info.inputType and 0xFFF) == 0x81) {
            requestHideSelf(0)
        }
    }
}
