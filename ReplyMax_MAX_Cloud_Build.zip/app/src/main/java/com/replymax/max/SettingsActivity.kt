package com.replymax.max

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(32,40,32,32)
            gravity=Gravity.CENTER_HORIZONTAL
        }
        val title=TextView(this).apply { text="ReplyMax MAX"; textSize=28f }
        val sub=TextView(this).apply {
            text="AI 高情商回复键盘\n\n支持微信、QQ、WhatsApp 等输入框。\nAI 云端模式需要你配置自己的模型 API。"
            textSize=16f
        }
        val enable=Button(this).apply {
            text="启用 ReplyMax 输入法"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        val privacy=TextView(this).apply {
            text="隐私：密码输入框自动隐藏 AI。默认不保存聊天内容。\n\n当前版本包含本地回复引擎；接入大模型后可获得更强的上下文理解。"
            textSize=14f
        }
        box.addView(title); box.addView(sub); box.addView(enable)
        box.addView(privacy)
        setContentView(box)
    }
}
