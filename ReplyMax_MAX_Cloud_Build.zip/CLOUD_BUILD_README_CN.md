# ReplyMax 手机云端编译说明

这个版本增加了 GitHub Actions 自动编译配置。无需在手机上安装 Android Studio。

## 手机操作流程

1. 在 GitHub 创建一个新仓库（建议 Public，便于使用 Actions）。
2. 将本目录中的全部文件上传到仓库根目录，保留 `.github/workflows/build-apk.yml`。
3. 打开仓库的 **Actions** → **Build ReplyMax APK**。
4. 点击 **Run workflow**（如果已经 push 到 main，也会自动开始）。
5. 等待绿色成功标记。
6. 打开这次运行记录，在页面底部的 **Artifacts** 下载 `ReplyMax-debug-apk`。
7. 解压得到 `.apk`，在 Android 手机上点击安装。

## 项目版本

- Android Gradle Plugin: 9.2.0
- Gradle: 9.4.1
- JDK: 17
- compileSdk: 36

Android 官方兼容性资料显示 AGP 9.2.0 使用 Gradle 9.4.1、JDK 17。 

注意：当前 APK 是 debug 构建；安装时 Android 可能要求允许浏览器/文件管理器“安装未知来源应用”。
